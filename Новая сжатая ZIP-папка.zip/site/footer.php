<div id="footer">
    <?php include SITE.'send.php';?>
    <div id="contacts">
        <img src="<?php echo SITE; ?>images/logo.png" width="285" height="118" />
        <div>
            Contact Information<br />
            Phone<br />
            +2 01016936293 <br />
            <br /><br />
            Address<br />
            Egypt, Cairo.<br />
            <br /><br />
            Email<br />
            <a href="mailto:admin@awebarts.com">admin@awebarts.com</a><br />
            <a href="mailto:ali_fergani2003@yahoo.com">ali_fergani2003@yahoo.com</a><br />
        </div>
    </div>
</div>
</div>
</body>
</html>