<?php

// header.php
include 'site/header.php';

// contents start
echo '<div id="contents">';

// sider bar
include 'site/sidebar.php';

echo '<div id="conts">';

// body which shows the home page contents
include 'site/sectionBody.php';

echo '</div>';

echo '</div>';

// footer.php
include 'site/footer.php';


?>
