<?php

// header.php
include 'site/header.php';

// contents start
echo '<div id="contents">';

// sider bar
include 'site/sidebar.php';

echo '<div id="conts">';

// slider
include 'site/slider.php';

// body which shows the home page contents
include 'site/body.php';

echo '</div>';

echo '</div>';

// footer.php
include 'site/footer.php';


?>
