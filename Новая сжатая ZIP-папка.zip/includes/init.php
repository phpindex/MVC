<?php

define('SITE', './site/');
define('APP', './app/');
define('MODELS', './app/models/');

