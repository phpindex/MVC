<?php 

$host     = "localhost";
$user     = "laravel";
$password = "laravel";
$database = "awebarts";


?>