<form class="mainSettingsForm add newPage" action="" method="POST" enctype="multipart/form-data">
    <h1>Add new Image:</h1>
    <input type="file" name="image[]" multiple="" />
    <input type="text" name="type" />
    <input type="submit" value="Upload" name="submit" />
</form>
